#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys, os, gc
from __init__ import *
import __init__
from utils import *
import argparse

class Tools(object):

   def __init__(self, dbServer='_buber3_', serverInstance=None, updateCounter=True):
      self._dbServer=dbServer
      self._serverInstance=serverInstance
      self._updateCounter=updateCounter
      self._mainPath=getScriptPath(f=__file__)
      self. _controlGC_last=getms(inMS=False)
      self._flagPause=None

   def _needInteractive(self):
      if not consoleIsTerminal():
         raise RuntimeError('This method need confirmation, so can be called only from interactive mode')

   def _needConfirm(self, msg):
      s='%sAre you sure you want to %s?%s (type "Yes"): '%(consoleColor.fail, msg, consoleColor.end)
      if raw_input(s)=='Yes': return True
      print 'Aborted'
      return False

   def _controlGC(self, pause=60*10):
      if not self._serverInstance or not self._serverInstance.settings['controlGC']: return
      # if self._serverInstance and self._serverInstance.settings['controlGC_allowDebug']:
      #    if getms(inMS=False)-self. _controlGC_last>60*1:
      #       print 'GARBAGE:'
      #       # self._serverInstance._controlGC_debug()
      #       gc.garbage
      #       raw_input()
      if getms(inMS=False)-self. _controlGC_last<pause: return
      self._serverInstance._controlGC()
      self. _controlGC_last=getms(inMS=False)

   def pause(self):
      self._flagPause=True

   def unpause(self):
      self._flagPause=False

   def _pause(self):
      if not self._flagPause: return
      sm=self._serverInstance._sleep if self._serverInstance else time.sleep
      print '>> PAUSED <<'
      while self._flagPause: sm(0.1)
      print '>> UNPAUSED <<'

   def findWordIndex(self):
      resMap={}
      res=[]
      count=0
      tArr1=sql.query('SELECT id, hash, letter, server, dbPostfix, tableName FROM letterIndex.letterIndex WHERE status=0', self._dbServer, selectMode='all', silentError=False)
      for o in tArr1:
         t='wordIndex%(dbPostfix)s.%(tableName)s'%o
         d=o['server']
         s='%s::%s'%(d, t)
         if s in resMap: continue
         c=numEx(sql.query('SELECT count(*) FROM %s'%(t), d, selectMode='str', silentError=False))
         n=numEx(sql.query('SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA="wordIndex%(dbPostfix)s" AND TABLE_NAME="%(tableName)s"'%o, d, selectMode='str', silentError=False))
         if not c and n==1: continue
         resMap[s]=None
         res.append({'table':t, 'server':d, 'count':c, 'nextId':n, 'tableName':o['tableName'], 'dbPostfix':o['dbPostfix']})
         count+=c
      return res, count

   def clearWordIndex(self):
      self._needInteractive()
      tArr, c=self.findWordIndex()
      if not len(tArr):
         print 'Nothing to clear'
         return
      if not self._needConfirm('clear %i WordIndexes, contained %i words'%(len(tArr), c)): return
      print 'Clearing..'
      count=0
      n=0
      for o in tArr:
         sql.query('TRUNCATE TABLE %(table)s'%o, o['server'], silentError=False)
         count+=numEx(sql.query('SELECT count(*) FROM %(table)s'%o, o['server'], selectMode='str', silentError=False))
         n+=numEx(sql.query('SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA="wordIndex%(dbPostfix)s" AND TABLE_NAME="%(tableName)s"'%o, o['server'], selectMode='str', silentError=False))
      if count:
         raise RuntimeError('WordIndex not empty after clearing (left %i words)'%count)
      if n!=len(tArr):
         raise RuntimeError('WordIndex not empty after clearing (some AUTO_INCREMENT not reseted)')
      print 'Completed!'

   def createCountryDB(self):
      self._needInteractive()
      data=fileGet('%s/.data/countries.txt'%(self._mainPath))
      data=data.split('|')
      data=' '.join(s for s in data if s and ' ' not in s)
      myMorpher=Morpher(serverInstance=self._serverInstance)
      morphObjAll=myMorpher.create(data, keepDoubles=True, groupBySentence=False, storeSentenceIndex=False, splitCombo=False)
      data=morphObjAll.keys()
      data=arrUnique(data)
      data=reprEx(data)
      if not self._needConfirm('overwrite countryDB'): return
      fileWrite('%s/data/countryDB_single.json'%(self._mainPath), data)
      print 'Completed!'

   def learnLiterature(self):
      self._needInteractive()
      # p='%s/.data/pushkin.txt'%(self._mainPath)
      # data=fileGet(p)
      pass

   def learnNews(self, skipLearned=True):
      self._needInteractive()
      if skipLearned:
         try:
            p='%s/data/newsLearned.json'%(self._mainPath)
            data=fileGet(p)
            learned=json.loads(data)
         except Exception, e:
            print '! Cant load learned cache from "%s": %s'%(p, e)
            learned={}
      else: learned={}
      tArr1=sql.query("SELECT table_name FROM information_schema.tables where table_schema='newsRawData'", self._dbServer, selectMode='all', silentError=False)
      source={}
      count=0
      for o in tArr1:
         sourceId=o['table_name']
         if isString(numEx(sourceId)): continue
         m=sql.query('SELECT min(uid), max(uid) FROM newsRawData.%s'%(sourceId), self._dbServer, selectMode='one', silentError=False)
         if not m: continue
         m1=numEx(m['min(uid)'])
         m2=numEx(m['max(uid)'])
         if isString(m1) or isString(m2): continue
         if sourceId in learned:
            m1=learned[sourceId]+1
         q='SELECT count(uid) FROM newsRawData.%s where uid>=%s and info!="{\\"notImplemented\\":true}"'%(sourceId, m1)
         c=numEx(sql.query(q, self._dbServer, selectMode='str', silentError=False))
         if not c: continue
         source[sourceId]=(m1, m2)
         count+=c
      if not self._updateCounter:
         print consoleColor.bold+consoleColor.warning+'Running without updating counters'+consoleColor.end
      if not self._needConfirm('process %i news from %i sources'%(count, len(source))): return
      print 'Processing..'
      myMorpher=Morpher(serverInstance=self._serverInstance)
      myIndexer=WordIndexer_DB(serverInstance=self._serverInstance)
      myIndexer.settings['sqlAllowExclusive']=True
      for sourceId, o in source.iteritems():
         uid, m=o
         while not uid>m:
            self._pause()
            data=sql.query('SELECT data FROM newsRawData.`%s` where uid=%s and info!="{\\"notImplemented\\":true}"'%(sourceId, uid), self._dbServer, selectMode='str', silentError=False)
            if data:
               t, l=self._learnText(sourceId, uid, data, myMorpher, myIndexer)
               print '%s:%s (%s) - %0.1f'%(sourceId, uid, l, t/1000.0)
               # raw_input()
            uid+=1
         learned[sourceId]=uid
      try:
         p='%s/data/newsLearned.json'%(self._mainPath)
         fileWrite(p, json.dumps(learned))
      except Exception, e:
         print '! Cant save learned cache to "%s": %s'%(p, e)
      print 'Completed!'

   def _learnText(self, sourceId, uid, data, morpher, indexer):
      mytime=getms(inMS=True)
      morphObjAll=morpher.create(data, keepDoubles=True, storeSentenceIndex=True, splitCombo=True)
      if len(morphObjAll)>1000:
         print '! So long text %s:%s (%s)'%(sourceId, uid, len(morphObjAll))
      indexer.all(morphObjAll, source=None, updateCounter=self._updateCounter)
      return getms(inMS=True)-mytime, len(morphObjAll)

   def testWithSemCorpus(self, name, table='manual', outPath='/home/python/semCorpus/testResults'):
      self._needInteractive()
      r=self._countSemCorpus(table)
      if not r:
         print 'Cant count semCorpus.%s'%table
      m1, m2, c=r
      if not self._needConfirm('run test on %i texts of Semantic Corpus "%s"'%(c, table)): return
      if self._updateCounter and not self._needConfirm('continue with updating counters'): return
      print 'Processing..'
      myMorpher=Morpher(serverInstance=self._serverInstance)
      myIndexer=WordIndexer_DB(serverInstance=self._serverInstance)
      myIndexer.settings['sqlAllowExclusive']=True
      mySenser=SenseExtractor(serverInstance=self._serverInstance, morpher=myMorpher, wordIndexer=myIndexer)
      res={
         'meta.json':{'name':name, 'table':table, 'resultName':[], 'resultCount':0, 'timestamp':datetime.datetime.now()}
      }
      for n, d in self._getCurrentLib().iteritems(): res['lib/%s'%n]=d
      for i in xrange(m1-1, m2+1):
         self._pause()
         q='SELECT source, text, morphed, sense, comment, `by` FROM semCorpus.%s where uid=%s and status=0'%(table, i)
         o=sql.query(q, self._dbServer, selectMode='one', silentError=False)
         if not o: continue
         d=o['source']
         if d in res:
            print '! Already existed in results: %s'%(d)
            continue
         t, sentenceGrouper, morphObjAll, rated=self._senseText(d, o['text'], myMorpher, mySenser)
         r=0 #! add calculating
         print '%s - %0.1f'%(d, t/1000.0)
         #add results
         try:
            res['%s/meta.json'%d]=encode_utf8(reprEx({'uid':i, 'source':d, 'comment':o['comment'], 'by':o['by'], 'result':r}))
            res['%s/text.txt'%d]=encode_utf8(o['text'])
            res['%s/morphedStandard.json'%d]=o['morphed']
            res['%s/senseStandard.json'%d]=o['sense']
            res['%s/morphed.json'%d]=encode_utf8(reprEx(morphObjAll))
            res['%s/sentences.json'%d]=encode_utf8(reprEx(sentenceGrouper))
            res['%s/rated.json'%d]=encode_utf8(reprEx(rated))
            res['%s/sense.json'%d]='[]'
         except Exception, e:
            print '!! Error while preparing results for %s: %s'%(d, e)
            continue
         res['meta.json']['resultName'].append(d)
         res['meta.json']['resultCount']+=1
      # write results to zip
      print 'Writing results to %s"%s/%s.zip"%s..'%(consoleColor.bold, outPath, name, consoleColor.end)
      res['meta.json']=encode_utf8(reprEx(res['meta.json']))
      s=zipWrite('%s/%s.zip'%(outPath, name), res, forceCompression=False)
      if s:
         print 'Completed!'

   def _senseText(self, source, data, morpher, senser):
      mytime=getms(inMS=True)
      sentenceGrouper, morphObjAll=morpher.create(data, keepDoubles=True, groupBySentence=True, storeSentenceIndex=True)
      if len(morphObjAll)>1000:
         print '! So long text %s (%s)'%(source, len(morphObjAll))
      rated=senser.extract((sentenceGrouper, morphObjAll, data), source=None, updateCounter=self._updateCounter, iterateAs='simple')
      return getms(inMS=True)-mytime, sentenceGrouper, morphObjAll, rated

   def _countSemCorpus(self, table):
      m=sql.query('SELECT min(uid), max(uid), count(uid) FROM semCorpus.%s'%(table), self._dbServer, selectMode='one', silentError=False)
      if not m: return None
      m1=numEx(m['min(uid)'])
      m2=numEx(m['max(uid)'])
      c=numEx(sql.query('SELECT count(uid) FROM semCorpus.%s where status=0'%(table), self._dbServer, selectMode='str', silentError=False))
      if isString(m1) or isString(m2) or isString(c): return None
      return m1, m2, c

   def _getCurrentLib(self):
      def tFunc(fp, f):
         if f.endswith('.pyc'): return False
         if f.startswith('.'): return False
      tArr={}
      for f in pathList(self._mainPath, fullPath=False, alsoFiles=True, alsoDirs=False, recursive=True, filter=tFunc):
         s=fileGet('%s/%s'%(self._mainPath, f))
         if not isString(s): continue
         tArr[f]=s
      return tArr

class DebugMemory(object):
   def __init__(self, serverInstance=None):
      self._serverInstance=serverInstance
      self._marked={}
      self.mark()

   def mark(self):
      self._marked=None
      self._marked=set(id(o) for o in gc.get_objects())

   def _find(self, typeOnly=None, sortBy=None, limit=2):
      self._serverInstance._controlGC(force=True)
      tArr2=set(self._marked) if self._marked else set()
      res={}
      for o in gc.get_objects():
      # for o in gc.garbage:
         if o is tArr2: continue
         if o is res: continue
         if o is self._marked: continue
         t=type(o)
         _t=str(t)
         _id=id(o)
         if typeOnly and typeOnly not in _t: continue
         if _t not in res:
            res[_t]={'type':t, '_type':_t, 'count':0, 'data':[], 'id':[], 'mem':0}
         if _id in res[_t]['id']: continue
         if self._marked and _id in self._marked: continue
         # res[_t]['data'].append(o)
         res[_t]['id'].append(_id)
         res[_t]['count']+=1
         # res[_t]['mem']+=getsize(o, seen=tArr2)
      if sortBy:
         sorter=sorted([k for k in res if res[k][sortBy]>=limit], key=lambda k:res[k][sortBy], reverse=True)
         return res, sorter
      else:
         return res

   def byType(self, limit=10, sortBy='count', typeOnly=None):
      res, sorter=self._find(sortBy=sortBy, limit=limit, typeOnly=typeOnly)
      tArr=['%s: %i - %s'%(res[k]['type'], res[k]['count'], size2human(res[k]['mem'])) for k in sorter]
      return tArr

   def gc(self):
      self._serverInstance._controlGC(force=True)

   def inspect(self, type, index=0):
      res=self._find(typeOnly=type)
      oid=res.values()[0]['id'][index]
      o=getObjectById(oid)
      r=gc.get_referrers(o)
      o=repr(o)
      r=[repr(s) for s in r]
      return o, r

   def test_sql(self):
      res={
         'pool':{k:len(v['cursorAll']) for k, v in sql._pools.iteritems()},
         'cursor':{k:len(v[1]) for k, v in sql._connections.iteritems()},
      }
      return res

def parseCLI():
   '<action> -key=value -key -key'
   parser=argparse.ArgumentParser(description='')
   # requiredNamed=parser.add_argument_group('required named arguments')
   # requiredNamed.add_argument('--api', '-a', type=str, default=None, help='Adress of rpc api (ip:port or uds-socket path)')
   actionGroup=parser.add_mutually_exclusive_group()
   actionGroup.add_argument("-t1", "--test1", type=str, default='def1', action="store")
   actionGroup.add_argument("-t2", "--test2", type=str, default='def2', action="store")
   # parser.add_argument('--updateCounters', '-u', type=str, default=True, help='Allow to update global counters of words')
   # parser.add_argument('--name', '-n', type=str, default='', help='Optional name of spider')
   cli=parser.parse_args()
   return cli

if __name__=='__main__':
   # print parseCLI()
   # zipWrite('%s/test.zip'%getScriptPath(f=__file__), {
   #    'dir1/test1.txt':'test1',
   #    'test3.json':'["test2"]'
   # }, 'a')
   # print zipGet('%s/test.zip'%getScriptPath(f=__file__), ['test3.json', 'dir1/test1.txt'], True)
   # s=fileGet('/home/python/semCorpus/testResults/morphed.json')
   # s=eval(s)
   # print_r(s)
   # print ('%s.%s__%s'%(__init__.__version__, __init__.__ver_sub__, datetime.datetime.now().strftime('%d-%m-%y__%H-%M-%S'))).replace('.', '-')
   # sys.exit(0)

   sql.pool('_buber3_', size=100, maxTry=30)
   from flaskJSONRPCServer import flaskJSONRPCServer
   dummyServer=flaskJSONRPCServer(('0.0.0.0', 12234), gevent=False, tweakDescriptors=True, debug=False, log=3, controlGC=False)
   tools=Tools(serverInstance=dummyServer, updateCounter=False)
   dummyServer.registerInstance(DebugMemory(serverInstance=dummyServer))
   dummyServer.registerFunction(tools.pause)
   dummyServer.registerFunction(tools.unpause)
   dummyServer.start()

   command=sys.argv[1] if len(sys.argv)>1 else None
   if command in ('-rwi', '--clearWordIndex'):
      tools.clearWordIndex()
   elif command in ('-ccdb', '--createCountryDB'):
      tools.createCountryDB()
   elif command in ('-ll', '--learnLiterature'):
      tools.learnLiterature()
   elif command in ('-ln', '--learnNews'):
      tools.learnNews()
   elif command in ('-tscm', '--testWithSemCorpusManual'):
      s=('%s.%s__%s'%(__init__.__version__, __init__.__ver_sub__, datetime.datetime.now().strftime('%d-%m-%y__%H-%M-%S'))).replace('.', '-')
      tools.testWithSemCorpus(s, table='manual')
   elif command in ('-v', '--version'):
      print '%s.%s'%(__init__.__version__, __init__.__ver_sub__)
   elif command in ('-h', '--help'):
      print 'Additional tools of Senser (%s). This args can be passed:'%__init__.__version__
      print '  "-h", "--help" for see this message'
      print '  "-v", "--version" for see version'
   else:
      print 'No args passed. Pass "-h" for see help.'
   while True: dummyServer._sleep(0.1)
