# -*- coding: utf-8 -*-
from utils import *
from morpher import wordClassConverter_en2ru, Morpher
import inspect

wordClassConverter_ru2int=wordClasses.WordClassConverter(wordClasses.ru2int)  #notExistCB=lambda o, s, t: None

class WordClassifier(object):
   """
   Классификатор служит для простановки дополнительных свойств слова, уточнения существующих и формирования 'classMask', являющейся совокупностью класса и спец флагов и служащей для более точной идентификации слова в индексаторе. В некоторых случая он также может менять оригинальный класс слова.
   """

   def __init__(self, wordClassConverter='en2ru', classToMaskConverter='ru2int'):
      if wordClassConverter=='en2ru':
         # предустановленный конвертер в русские названия классов
         self.wordClassConverter=wordClassConverter_en2ru
      else:
         self.wordClassConverter=wordClassConverter or None
      if classToMaskConverter=='ru2int':
         # предустановленный конвертер в числовые названия классов
         self.classToMaskConverter=wordClassConverter_ru2int
      else:
         self.classToMaskConverter=classToMaskConverter or None
      self._classesSingle=ClassesSingle(wordClassConverter=self.wordClassConverter)
      self._classesMulti=ClassesMulti(wordClassConverter=self.wordClassConverter)

   def createClassMask(self, word, morphObj):
      cl=morphObj['params']['class']
      if self.classToMaskConverter:
         cl=self.classToMaskConverter.byId(cl)
      else:
         raise ValueError('For creating class mask we need classToMaskConverter')
      fl=flagToMask(word, morphObj)*100
      sp=0
      r=sp+fl+cl
      morphObj['params']['classMask']=r

   def one(self, word, morphObj, onlySingle=True):
      if not onlySingle:
         morphObjAll=morphObj
         morphObj=morphObj[word]
         r, word=self._classesMulti(word, morphObjAll)
         if r is True:
            self.createClassMask(word, morphObj)
            return word
      _, word=self._classesSingle(word, morphObj)
      self.createClassMask(word, morphObj)
      return word

   def all(self, morphObjAll):
      forDel=[]
      for word in morphObjAll.iterkeys():
         word2=self.one(word, morphObjAll, onlySingle=False)
         if word2!=word:
            morphObjAll[word2]=morphObjAll[word]
            forDel.append(word)
      for word in forDel:
         del morphObjAll[word]

def flagToMask(word, morphObj):
   """ Конвертирует спец флаги в значение он 10 до 99 """
   if False: return 10  #reserved
   elif morphObj['params']['info'].get('isCountry'): return 11
   elif morphObj['params']['info'].get('isCombo'): return 12
   return 0

class Classes(object):
   """ Базовый класс для класcификаторов. """

   def __init__(self, wordClassConverter):
      self.wordClassConverter=wordClassConverter
      self._skipMethods=('__init__', 'do', 'wordClassConverter')

   def do(self, word, morphObj):
      r=None
      for k, v in inspect.getmembers(self, predicate=inspect.ismethod):
         if k in self._skipMethods or k[0]=='_': continue
         clsOld=morphObj['params']['class']
         tArr=v(word, morphObj) or (None,)
         if morphObj['params']['class']!=clsOld and self.wordClassConverter:
            morphObj['params']['class']=self.wordClassConverter.byId(morphObj['params']['class'])
         if len(tArr)>1: word=tArr[1]
         r=tArr[0]
         if r is True: break
      return r, word

   __call__=do

# init classifier's dbs
dbPath='%s/data'%getScriptPath(f=__file__)
classifierDB={}
classifierDB['country']={}
classifierDB['country']['single']=set(json.loads(fileGet('%s/countryDB_single.json'%dbPath)))

class ClassesSingle(Classes):
   """ Классификаторы, которым достаточно одного слова. """

   def properName(self, word, morphObj):
      if not morphObj['params']['info'].get('isCapital'): return
      if not any(morphObj['wordsIndex']): return
      # more complex check, if capitalized word is not first word
      for i, w in enumerate(morphObj['words']):
         if morphObj['wordsIndex'][i] and w[0].isupper() and not w.isupper(): break
      else: return
      morphObj['params']['class']='name'

   def country(self, word, morphObj):
      if word not in classifierDB['country']['single']: return
      morphObj['params']['class']='name'
      morphObj['params']['info']['isCountry']=True

class ClassesMulti(Classes):
   """ Классификаторы, которым нужен весь текст. """

   def country(self, word, morphObj):
      return  #! теоретически можно найти и страны, состоящие более чем из одного слова

if __name__ == '__main__':
   pass
